// Wait till the browser is ready to render the game (avoids glitches)
window.requestAnimationFrame(function () {
    let targetScore = parseInt(prompt('Enter the target score:'),10);
    new GameManager(4, KeyboardInputManager, HTMLActuator, LocalStorageManager, UrulAutoplayStrategy,targetScore);
  });
  