class Score
{
    static #target;
    static SetScore(target)
    {
        if(Number.isSafeInteger(target)==false)
        {
            Score.#target = 0 ;
            return ;
        }

        Score.#target = Math.max( target , 0 );
    }

    static IsWin(curr)
    {
        if(Number.isSafeInteger(curr)==false)
        {
            return false;
        }
        GameStatus.won = ( (curr>= Score.#target) ? true : false );
        return GameStatus.won;
    }

    static GetScore()
    {
        return Score.#target;
    }
}