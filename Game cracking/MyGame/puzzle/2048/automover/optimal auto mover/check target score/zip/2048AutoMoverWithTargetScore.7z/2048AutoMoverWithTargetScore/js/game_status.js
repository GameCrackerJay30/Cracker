class GameStatus
{
    static won;
    static Init()
    {
        GameStatus.won = false;
    }
    static CheckWin()
    {
        if(GameStatus.won == true)
        {
            alert("You won.");
        }else
        {
            alert("You lose.");
        }
    }
}